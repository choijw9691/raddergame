# RulletLadder

[Android & Java] Ladder style Rullet game.

I made Ladder style Rullet game by using Canvas api. 
How to play?
= Input member's count & name & present name
= Press 'Start' button


[Image1 : Input member's count & name & present name ]
[Image2 : Game Activity]
[Image3 : Game animation]
[Image4 : Game result]

<div>
<img src="https://github.com/DonggeunJung/RulletLadder/blob/master/RulletLadder_Capture01.png?raw=true width="400px"></img>
<img src="https://github.com/DonggeunJung/RulletLadder/blob/master/RulletLadder_Capture02.png?raw=true width="400px"></img>
<img src="https://github.com/DonggeunJung/RulletLadder/blob/master/RulletLadder_Capture03.png?raw=true width="400px"></img>
<img src="https://github.com/DonggeunJung/RulletLadder/blob/master/RulletLadder_Capture04.png?raw=true width="400px"></img>
</div>

< Used Android API >
1. Canvas
2. Event Handler
3. AlderDialog


< Additional Infomation >

GitHub Link : https://github.com/DonggeunJung/RulletLadder

Any question => Email : topsan72@gmail.com / Author : Donggeun Jung (Dennis)
